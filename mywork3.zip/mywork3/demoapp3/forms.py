from django import forms
from demoapp3.models import *
class workform(forms.ModelForm):
    class Meta:
        model=workcomplete
        fields='__all__'