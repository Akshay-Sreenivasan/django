from django.db import models

# Create your models here.
class workcomplete(models.Model):
    empname=models.CharField(max_length=25)
    empmail=models.EmailField()
    work=models.CharField(max_length=25)
    progress=models.CharField(max_length=25)