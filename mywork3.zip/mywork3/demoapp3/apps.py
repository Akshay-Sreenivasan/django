from django.apps import AppConfig


class Demoapp3Config(AppConfig):
    name = 'demoapp3'
