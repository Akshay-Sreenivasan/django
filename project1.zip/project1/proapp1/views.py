from django.shortcuts import render
from proapp1.models import *
from proapp1.forms import *
# Create your views here.

def home(request):
    return render(request,'home.html')
def add_item(request):
    form=Empform()
    if request.method=='POST':
        form=Empform(request.POST)
        if form.is_valid():
            form.save()
            return list(request)
    return render(request,'add.html',{'form':form})
def list(request):
    b=Employee.objects.all()
    return render(request,'list.html',{'d':b})
def edit_item(request,p):
    b=Employee.objects.get(pk=p)
    form=Empform(instance=b)
    if request.method=='POST':
        form=Empform(request.POST,instance=b)
        if form.is_valid():
            form.save()
            return list(request)
    return render(request,'edit.html',{'form':form})
def delete_item(request,p):
    b=Employee.objects.get(pk=p)
    b.delete()
    return list(request)
